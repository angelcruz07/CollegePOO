package interfaces;

public interface Game {
    // No requerimos que se especifique, public o abstract ya que lo tienen por defecto
    void init();
    void play();
    void finish(); 
    
}
